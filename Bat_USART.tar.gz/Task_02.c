

#include "ROOT.h"
#include <string.h>


unsigned char Task_02_Step		= 0;

//#################################################################################
//#
		#include <util/delay.h>
		#include <avr/interrupt.h>
		#include <avr/sleep.h>

		void gamura(void);

		#define DD_HCRS04_Trig_Out			DDRD |=  (1 << 4);		// Test
		#define DD_HCRS04_Trig_In			DDRD &= ~(1 << 4);		// Test
		#define DD_HCRS04_Echo_Out			DDRD |=  (1 << 5);		// Test
		#define DD_HCRS04_Echo_In			DDRD &= ~(1 << 5);		// Test

		#define HCRS04_Trig_1				PORTD |=  (1 << 4);		// Test
		#define HCRS04_Trig_0				PORTD &= ~(1 << 4);		// Test


		union
		{   unsigned long _long;
			unsigned short _short;
			unsigned char  _char[4];
		} MyVel;


		union
		{
			unsigned long _a1;
			unsigned char  _a4[4];

		} all;
//#
//#################################################################################

void Task_02(void)
{
	switch(Task_02_Step )
	{
		case 0 :
		{
			break;
		}

		//################################################################################

		case 1 :
		{
			gamura();
			break;
		}
		case 2 :
		{


			Task_02__Task_Stop;
			break;
		}
		case 3 :
		{


			Task_02__Task_Stop;
			break;
		}

		case 4 :
		{


			Task_02__Task_Stop;
			break;
		}

		case 5 :
		{

			Task_02__Task_Stop;
			break;
		}




	}
}

//#################################################################
void gamura_init(void) {

	DD_HCRS04_Trig_Out;
	DD_HCRS04_Echo_In;

}
void gamura(void) {

		char x1 = 0;
		HCRS04_Trig_1;
		_delay_ms(200);
		HCRS04_Trig_0;

		x1 = PIND & 0b00100000;

		if (x1==0){

			// velodebi ertians
			while(1){
				x1 = PIND & 0b00100000;
				if (x1!=0) break;
			}

			MyVel._long =  0; PORTA = 0; PORTB = 0; PORTC = 0;

			// ertianis xangdzlivobis gansazgvra
			while(1){
				MyVel._long++;
				x1 = PIND & 0b00100000;
				if (x1==0) break;
			}

			USART_Waiting_For_Free;
			sprintf(USART_buffer,"xDistance is: %lu\n\r", MyVel._long);
			USART_Transmit();

			unsigned char i;
			unsigned long st = 325;
			all._a1 = 1;

			for (i = 0; i <= 24; i++) {
					if (st < MyVel._long) {
						st += 325;
						all._a1 = all._a1 << 1;
						all._a1+=1;
					}
			}

			PORTA= all._a4[0];
			PORTB= all._a4[1];
			PORTC= all._a4[2];

			_delay_ms(8);

		}else{
			_delay_ms(25);
		}
}
