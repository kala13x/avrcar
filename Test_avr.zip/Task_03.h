
#define Task_03__GoTo_Next_Step			Task_03_Step += 1
#define Task_03__Task_Stop			Task_03_Step  = 0
#define Task_03__Task_Start			Task_03_Step  = 1


extern unsigned char Task_03_Step ;



void Task_03(void);



