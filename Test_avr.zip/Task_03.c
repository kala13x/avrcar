
#include "ROOT.h"
#include <string.h>


unsigned char Task_03_Step		= 0;



void Task_03(void)
{
	switch(Task_03_Step )
	{
		case 0 :
		{
				if (USART0_Vel == 'x'){
					Task_03__GoTo_Next_Step;
				}

			break;
		}

		//################################################################################

		case 1 :
		{
				if (USART0_Vel == 'y'){
					Task_03__GoTo_Next_Step;
				}else{
					if(USART0_Vel != 'x'){
						Task_03__Task_Stop;
					}

				}
			break;
		}
		case 2 :
		{
				if (USART0_Vel == '1') {
					Task_01__Task_Start;
				}

				if (USART0_Vel == '2') {
					Task_02__Task_Start;
				}

				Task_03__Task_Stop;


			break;
		}
		case 3 :
		{


			Task_03__Task_Stop;
			break;
		}

		case 4 :
		{


			Task_03__Task_Stop;
			break;
		}

		case 5 :
		{

			Task_03__Task_Stop;
			break;
		}




	}
}
